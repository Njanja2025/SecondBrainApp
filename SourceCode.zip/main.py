# Main logic of SecondBrainApp
print('Hello from SecondBrainApp')